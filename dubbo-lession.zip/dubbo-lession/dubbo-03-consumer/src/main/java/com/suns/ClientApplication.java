package com.suns;

import com.suns.service.UserService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

public class ClientApplication {
    public static void main(String[] args) throws IOException {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext-consumer.xml");
        UserService userService = (UserService) applicationContext.getBean("userService");

        boolean ret = userService.login("xiaohei", "123456");
        System.out.println("ret = " + ret);

        System.in.read();

    }
}
