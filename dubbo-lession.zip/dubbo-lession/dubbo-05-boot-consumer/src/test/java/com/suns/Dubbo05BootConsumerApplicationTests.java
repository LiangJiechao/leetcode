package com.suns;

import com.suns.service.UserService;
import org.apache.dubbo.config.annotation.DubboReference;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dubbo05BootConsumerApplicationTests {

    @DubboReference(url = "dubbo://192.168.50.62:20880/com.suns.service.UserService")
    private UserService userService;

    @Test
    void contextLoads() {
    }

    @Test
    public void test1() {
        boolean ret = userService.login("xiaohei", "123456");
        System.out.println("ret = " + ret);
    }
}
